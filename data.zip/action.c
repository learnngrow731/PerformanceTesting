Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=89", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0gpVKF02s7Ho0CgYIARAAGBASNwF-L9Ir2D80opsSRct-r6_LLC4QIij2REGo9HfqLqiPFr-dbPB5ze1_ufB4_ESm6W-DpXa2QQE&scope=https://www.googleapis.com/auth/chromesync", 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_6.pb", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("token_2", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0gpVKF02s7Ho0CgYIARAAGBASNwF-L9Ir2D80opsSRct-r6_LLC4QIij2REGo9HfqLqiPFr-dbPB5ze1_ufB4_ESm6W-DpXa2QQE", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_url("Account.action", 
		"URL=https://petstore.octoperf.com/actions/Account.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChNDaHJvbWUvODkuMC40Mzg5LjkwEhAJ34e8yo8bLA8SBQ0Cj_toEhcJPBi8VCVDHfASBQ3njUAOEgUNzkFMeg==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("T01_Click_RegisterNow");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(43);

	web_url("Register Now!", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid=D0D081CC3BF455AFF1DD825A23E6993C?newAccountForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,obedbbhbpmojnkanicioggnmelmoomoc,giekcmmlnklenlaomppkphknjmnnpneh,oimompecagnajdejgnnjijobebaeigek,khaoiebndkojlmppeemjhbpbandiljpe,hnimpnehoodheedghdeeijklkeaacbdc,gcmjkmgdlgnkkcocmoeiminaijmmjnii,cmahhnpholdijhjokonmfdjbfmklppij,llkgjffcdpffmhiakmfcdcblohccpfmo,aemomkdncapdnfajjbbcbdebjljbpmpj,hfnkpimlhhgieaddgfemjhofmfblmnib,jflookgnkcckhobaglndicnbbgbonegd,ehgidpndbllacpjalkiimkbadgjfnnmc,ggkkehgbnfjpeggfpleeakpidbkibbmn,ojhpjlocmbogdgmfpkhlaaeamibhnphh,"
		"bklopemakmnopmghhmccadeonafabnal,gkmgaooipdjhmangpemjhigmamcehddo,jamhcnnkihinmdlkakkaopbjbbcngflc,eeigpngbgcognadeebkilcpcaedhellh");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-89.0.4389.90");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=10:3043958599&cup2hreq=b2193b6dd44dbb2e659bc1c38219ed88c725f1415f1ac45b3489241fa17e6719", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{8e947d49-be72-4632-88bc-d6315e1d7d2b}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"accept_locale\":\"ENUS1000000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\","
		"\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3b5abf25aaf97128ec6eb6ef1dfbd59594058a79dacbf33e2327d74348fa4dc3\"}]},\"ping\":{\"ping_freshness\":\"{92d373c6-4e4b-4e16-9be3-0f2c31e46165}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"20210312.363650474\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{18fa4047-0283-47f1-857f-82c81a261778}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{06657229-ec35-4e7a-ba2e-6d3551acadfa}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"4.10.2209.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ffd1d2d75a8183b0a1081bd03a7ce1d140fded7a9fb52cf3ae864cd4d408ceb4\"}]},\"ping\":{\"ping_freshness\":\"{5dd218b8-94f2-4311-a7d4-e091fde3f49d}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"43\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"}]},\"ping\":{\"ping_freshness\":\"{4d68c760-b395-46b6-b98c-aab31f4fdb7b}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.869f6197c3fdd474910319ff37ee13b73f8fb8ceeaaa62517e2d056b6a03ff54\"}]},\"ping\":{\""
		"ping_freshness\":\"{a7084ea3-dc9e-4985-950b-22bbf681cbd8}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"9.19.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"GGLS\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.75852854551de8eddabf86ee0353550aae352f9449fdc5c2fb6ff024968393ed\"}]},\"ping\":{\"ping_freshness\":\"{92a17de1-8e05-4b1a-9183-6b8294159cee}\",\"rd\":5195},\"updatecheck\":{},\"version\":\""
		"1.0.5\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.d730fdd6875bfda19ae43c639e89fe6c24e48b53ec4f466b1d7de2001f97e03c\"}]},\"ping\":{\"ping_freshness\":\"{3e6aab0e-cdf8-477d-8ca1-d73101a42e3e}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\""
		"{79a59a2a-d2f7-40cc-84ff-42f8693ea8da}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.789f3d50a09d90b22ba4f291468c93e56fc0c75d68b46ddc99a0546aa0d6ec9a\"}]},\"ping\":{\"ping_freshness\":\"{6731959d-3f69-4072-a39a-51a3a7114757}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"6500\"},{\"appid\":\""
		"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3175d4e2fc7fc866e6928bf5440f7ceb3b993d0c4d4b4c1a103a1aeb1939e38a\"}]},\"ping\":{\"ping_freshness\":\"{147287e1-f92b-4d9b-ae37-98bc41f4a5d0}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"2600\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:p93:\",\"cohorthint\":\"stable32\",\""
		"cohortname\":\"stable32\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a4811ca3f1d231f2cbb8e5ffbacf475f3364e0a4be162e8758578c76a31ce58f\"}]},\"ping\":{\"ping_freshness\":\"{c22e90e2-f09b-423f-a228-b65b74fe8cea}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"2018.7.19.1\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9:zar@0.01\",\"cohorthint\":\"M80ToM99\",\"cohortname\":\"M80ToM99\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.0d57ad1c6b9993013967d39082cff2565143fb56a8a9bb4b70b0234f8b86c301\"}]},\"ping\":{\"ping_freshness\":\"{88eb2345-17d5-4888-a60d-7d01958c6b48}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"2021.3.15.1141\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\""
		"{af52c445-bc37-4411-984d-e1df1002d2f3}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"1\"},{\"appid\":\"bklopemakmnopmghhmccadeonafabnal\",\"brand\":\"GGLS\",\"cohort\":\"1:swl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.70497f45af368f6d591eb9b93a097b7b56821b0770ee00f04b2f5901487a0421\"}]},\"ping\":{\"ping_freshness\":\"{41b4b0b4-94a2-4065-a2cc-0145a844d734}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"4\"},{\"appid\":\""
		"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GGLS\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.b1e4363fc57b99df204b9afa1faee4e4aa4accc1ba7ed801777101b2587469a9\"}]},\"ping\":{\"ping_freshness\":\"{f585a713-9e57-4a24-9c83-6ec32974bdbf}\",\"rd\":5195},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"89.257.200\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ad6f298dd57c686c76645ac8e73d600a10e7a9f67cbecbec4bf77edb69f5c806\"}]},\"ping\":{\"ping_freshness\":\"{de5a1acb-7f1b-4ba9-937d-e20d510eda0f}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"91.0.4457.0\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{3ed16a26-4425-4e76-91ee-46d7eaf6a10a}\",\"rd\":5195},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x86\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"physmemory\":2},\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"sp\":\"Service Pack 1\",\"version\":\"6.1.7601.0\"},\"prodversion\":\"89.0.4389.90\",\"protocol\":\"3.1\",\""
		"requestid\":\"{e26572c0-a6cd-4359-8448-5c86dd449b6d}\",\"sessionid\":\"{4b517089-aeba-4a74-b7f4-d3c369cd9858}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.72\"},\"updaterversion\":\"89.0.4389.90\",\"wow64\":true}}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"ChwKDGdvb2dsZWNocm9tZRIMODkuMC40Mzg5LjkwGicIARABGhkKDQgBEAYYASIDMDAxMAMQFBoCGARPXULuIgQgASACKAMaJwgJEAEaGQoNCAkQBhgBIgMwMDEwBhADGgIYBDI7R8MiBCABIAIoBhopCAcQARobCg0IBxAGGAEiAzAwMTABEPqPCRoCGAT1FwH1IgQgASACKAEaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARCN6AoaAhgE1mgAvSIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQoR4aAhgEvUBfhSIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAEQHxoCGASdmKtKIgQgASACKAEaKAgIEAEaGgoNCAgQBhgBIgMwMDEwARDXCxoCGATJ4evPIgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARCdhgEaAhgEaFVOoCIEIAEgAigBGikIARABGhsKDQ"
		"gBEAYYASIDMDAxMAEQ-9MIGgIYBLUC_MciBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAYaAhgEcSpGWiIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQycsIGgIYBPKzVGkiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEMwJGgIYBHCol8IiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEPyfBRoCGAQW3VJaIgQgASACKAEaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARDoXBoCGATd0MhrIgQgASACKAEiAggD&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("T01_Click_RegisterNow",LR_AUTO);

	lr_start_transaction("T02_UserInformation");

	/* save account info */

	lr_end_transaction("T02_UserInformation",LR_AUTO);

	return 0;
}